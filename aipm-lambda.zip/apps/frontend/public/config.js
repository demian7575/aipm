window.__AIPM_API_BASE__ = window.__AIPM_API_BASE__ || '';
