import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {
  COMPONENT_CATALOG,
  createApp,
  DATABASE_PATH,
  openDatabase,
  resetDatabaseFactory,
} from '../apps/backend/app.js';
import { generateSampleDataset } from '../scripts/generate-sample-dataset.mjs';

process.env.AI_PM_DISABLE_OPENAI = '1';
delete process.env.AI_PM_OPENAI_API_KEY;
delete process.env.OPENAI_API_KEY;

async function resetDatabaseFiles() {
  await fs.rm(DATABASE_PATH, { force: true });
  await fs.rm(`${DATABASE_PATH}.json`, { force: true });
}

async function startServer() {
  const app = await createApp();
  return new Promise((resolve) => {
    const server = app.listen(0, () => {
      const { port } = server.address();
      resolve({ server, port });
    });
  });
}

test('stories CRUD with reference documents', async (t) => {
  await resetDatabaseFiles();
  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;

  const storiesResponse = await fetch(`${baseUrl}/api/stories`);
  assert.equal(storiesResponse.status, 200);
  const stories = await storiesResponse.json();
  assert.ok(Array.isArray(stories));
  assert.equal(stories.length, 1);
  const story = stories[0];
  const originalTestCount = Array.isArray(story.acceptanceTests) ? story.acceptanceTests.length : 0;
  const originalTaskCount = Array.isArray(story.tasks) ? story.tasks.length : 0;
  assert.equal(story.title, 'Root');
  assert.equal(story.asA, 'AI project manager');
  assert.equal(story.iWant, 'coordinate autonomous planning across AIPM components');
  assert.equal(story.soThat, 'teams can deliver measurable outcomes with shared context');
  assert.equal(story.storyPoint, 5);
  assert.equal(story.assigneeEmail, 'owner@example.com');
  assert.ok(Array.isArray(story.components));
  assert.deepEqual(story.components, ['WorkModel', 'Orchestration_Engagement']);
  assert.ok(Array.isArray(story.tasks));
  assert.equal(story.tasks.length, 0);
  assert.ok(Array.isArray(story.dependencies));
  assert.equal(story.dependencies.length, 0);
  assert.ok(Array.isArray(story.dependents));
  assert.equal(story.dependents.length, 0);
  assert.ok(Array.isArray(story.blockedBy));
  assert.equal(story.blockedBy.length, 0);
  assert.ok(Array.isArray(story.blocking));
  assert.equal(story.blocking.length, 0);
  assert.ok(Array.isArray(story.children));
  assert.equal(story.children.length, 0);
  assert.ok(story.investHealth);
  assert.equal(typeof story.investHealth.satisfied, 'boolean');
  assert.ok(Array.isArray(story.investHealth.issues));
  assert.ok(story.investAnalysis);
  assert.ok(Array.isArray(story.investAnalysis.aiWarnings));
  assert.ok(Array.isArray(story.investAnalysis.fallbackWarnings));
  assert.equal(typeof story.investAnalysis.usedFallback, 'boolean');
  assert.ok(['heuristic', 'fallback', 'openai'].includes(story.investAnalysis.source));
  assert.ok(
    story.investHealth.issues.every(
      (issue) => !/acceptance tests reach Pass status/i.test(issue.message)
    )
  );
  if (story.acceptanceTests.length) {
    assert.ok(story.acceptanceTests[0].gwtHealth);
    assert.equal(typeof story.acceptanceTests[0].gwtHealth.satisfied, 'boolean');
  }

  const primaryComponents = COMPONENT_CATALOG.length
    ? COMPONENT_CATALOG.slice(0, Math.min(2, COMPONENT_CATALOG.length))
    : ['WorkModel'];
  const patchResponse = await fetch(`${baseUrl}/api/stories/${story.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      storyPoint: 8,
      assigneeEmail: 'owner@example.com',
      title: story.title,
      description: story.description,
      components: primaryComponents,
      acceptWarnings: true,
    }),
  });
  assert.equal(patchResponse.status, 200);
  const updated = await patchResponse.json();
  assert.equal(updated.storyPoint, 8);
  assert.equal(updated.assigneeEmail, 'owner@example.com');
  assert.deepEqual(updated.components, primaryComponents);
  assert.ok(Array.isArray(updated.acceptanceTests));
  assert.ok(Array.isArray(updated.tasks));
  assert.ok(updated.tasks.length >= story.tasks.length);
  assert.ok(
    updated.tasks.every((task) => typeof task.assigneeEmail === 'string' && task.assigneeEmail.trim().length > 0),
    'Updated story payload should include task assignees'
  );
  assert.ok(
    updated.acceptanceTests.length >= originalTestCount + 1,
    'Story update should retain existing tests and add a draft verification'
  );
  if (originalTestCount > 0) {
    assert.ok(
      updated.acceptanceTests.some((test) => test.status === 'Need review with update'),
      'Existing acceptance tests should require review after story edits'
    );
  }
  const draftTests = updated.acceptanceTests.filter((test) => test.status === 'Draft');
  assert.ok(draftTests.length >= 1, 'Story edits should create a draft acceptance test');
  assert.ok(
    draftTests.every((test) => Array.isArray(test.then) && test.then.length > 0),
    'Draft acceptance tests should include Then steps'
  );

  const blockedResponse = await fetch(`${baseUrl}/api/stories/${story.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: updated.title,
      description: updated.description ?? '',
      components: updated.components,
      storyPoint: updated.storyPoint,
      assigneeEmail: updated.assigneeEmail,
      status: 'Blocked',
      asA: updated.asA ?? story.asA,
      iWant: updated.iWant ?? story.iWant,
      soThat: updated.soThat ?? story.soThat,
      acceptWarnings: true,
    }),
  });
  assert.equal(blockedResponse.status, 200);
  const blockedStory = await blockedResponse.json();
  assert.equal(blockedStory.status, 'Blocked');

  const healthResponse = await fetch(`${baseUrl}/api/stories/${story.id}/health-check`, {
    method: 'POST',
  });
  assert.equal(healthResponse.status, 200);
  const healthStory = await healthResponse.json();
  assert.ok(Array.isArray(healthStory.acceptanceTests));
  assert.ok(Array.isArray(healthStory.components));
  assert.deepEqual(healthStory.components, primaryComponents);
  assert.ok(
    healthStory.acceptanceTests.length >= originalTestCount + 1,
    'Health check should return acceptance tests including the new draft after story update'
  );
  if (originalTestCount > 0) {
    assert.ok(
      healthStory.acceptanceTests.filter((test) => test.status === 'Need review with update').length >= originalTestCount,
      'Health check should preserve review-needed status for existing tests'
    );
  }

  const childComponents = COMPONENT_CATALOG.slice(2, 4).length
    ? COMPONENT_CATALOG.slice(2, 4)
    : primaryComponents;
  const childResponse = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Child estimation',
      parentId: story.id,
      storyPoint: 3,
      assigneeEmail: 'engineer@example.com',
      description: 'Implements supporting UI',
      asA: 'User',
      iWant: 'complete a two-factor login',
      soThat: 'my account stays safe',
      components: childComponents,
    }),
  });
  assert.equal(childResponse.status, 201);
  const child = await childResponse.json();
  assert.equal(child.storyPoint, 3);
  assert.deepEqual(child.components, childComponents);
  assert.ok(child.investHealth);
  assert.ok(child.investAnalysis);
  assert.ok(Array.isArray(child.investAnalysis.aiWarnings));
  assert.ok(Array.isArray(child.investAnalysis.fallbackWarnings));
  assert.ok(Array.isArray(child.acceptanceTests));
  assert.ok(child.acceptanceTests.length >= 1, 'New child story should have an automatic acceptance test');
  assert.ok(Array.isArray(child.tasks));
  assert.ok(child.tasks.length >= 0);
  assert.ok(
    child.tasks.every((task) => typeof task.assigneeEmail === 'string' && task.assigneeEmail.trim().length > 0),
    'Child story tasks should include assignees'
  );
  assert.ok(
    child.acceptanceTests.every((test) => test.status === 'Draft'),
    'Automatically created acceptance tests start as Draft'
  );
  assert.ok(
    child.acceptanceTests.every((test) => Array.isArray(test.then) && test.then.length > 0),
    'Automatically created acceptance tests include Then steps'
  );

  const draftIdea =
    'As a compliance officer I want audit logging so that we meet regulations and pass audits';
  const draftResponse = await fetch(`${baseUrl}/api/stories/draft`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ idea: draftIdea, parentId: story.id }),
  });
  assert.equal(draftResponse.status, 200);
  const draftStory = await draftResponse.json();
  assert.equal(typeof draftStory.title, 'string');
  assert.ok(draftStory.title.toLowerCase().includes('audit logging'));
  assert.equal(draftStory.asA, 'Compliance officer');
  assert.ok(draftStory.iWant.toLowerCase().includes('audit'));
  assert.equal(draftStory.soThat, 'We meet regulations and pass audits');
  assert.ok(
    draftStory.description.includes('As a Compliance officer'),
    'Generated description should mention the persona'
  );
  assert.ok(
    draftStory.description.toLowerCase().includes('implement audit logging'),
    'Generated description should describe the goal naturally'
  );
  assert.equal(draftStory.storyPoint, 4);
  assert.equal(draftStory.assigneeEmail, 'owner@example.com');
  assert.ok(Array.isArray(draftStory.components));
  assert.deepEqual(draftStory.components, updated.components);

  const aiDraftResponse = await fetch(`${baseUrl}/api/stories/${story.id}/tests/draft`, {
    method: 'POST',
  });
  assert.equal(aiDraftResponse.status, 200);
  const aiDraft = await aiDraftResponse.json();
  assert.ok(Array.isArray(aiDraft.given) && aiDraft.given.length > 0);
  assert.ok(Array.isArray(aiDraft.when) && aiDraft.when.length > 0);
  assert.ok(Array.isArray(aiDraft.then) && aiDraft.then.length > 0);
  assert.equal(aiDraft.status, 'Draft');

  const ideaText = 'validate audit log entries for approved changes';
  const ideaDraftResponse = await fetch(`${baseUrl}/api/stories/${story.id}/tests/draft`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ idea: ideaText }),
  });
  assert.equal(ideaDraftResponse.status, 200);
  const ideaDraft = await ideaDraftResponse.json();
  assert.ok(Array.isArray(ideaDraft.when) && ideaDraft.when.length > 0);
  assert.ok(
    ideaDraft.when.some((step) => step.toLowerCase().includes('validate audit log entries')),
    'When step should incorporate the provided idea'
  );
  assert.ok(
    ideaDraft.given.some((step) => step.toLowerCase().includes('idea "validate audit log entries for approved changes"')),
    'Given step should reference the supplied idea explicitly'
  );
  assert.ok(Array.isArray(ideaDraft.then) && ideaDraft.then.length > 0);
  assert.equal(ideaDraft.status, 'Draft');

  const taskCreateResponse = await fetch(`${baseUrl}/api/stories/${story.id}/tasks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Validate login analytics',
      status: 'In Progress',
      description: 'Review telemetry and confirm KPI coverage.',
      assigneeEmail: 'qa@example.com',
    }),
  });
  assert.equal(taskCreateResponse.status, 201);
  const createdTask = await taskCreateResponse.json();
  assert.equal(createdTask.title, 'Validate login analytics');
  assert.equal(createdTask.status, 'In Progress');
  assert.equal(createdTask.assigneeEmail, 'qa@example.com');

  const missingAssigneeResponse = await fetch(`${baseUrl}/api/stories/${story.id}/tasks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Unassigned task',
      status: 'Not Started',
      description: 'Should fail due to missing assignee',
    }),
  });
  assert.equal(missingAssigneeResponse.status, 400);
  await missingAssigneeResponse.text();

  const taskUpdateResponse = await fetch(`${baseUrl}/api/tasks/${createdTask.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      status: 'Done',
      description: 'Telemetry confirms success.',
      assigneeEmail: 'lead.qa@example.com',
    }),
  });
  assert.equal(taskUpdateResponse.status, 200);
  const updatedTask = await taskUpdateResponse.json();
  assert.equal(updatedTask.status, 'Done');
  assert.equal(updatedTask.description, 'Telemetry confirms success.');
  assert.equal(updatedTask.assigneeEmail, 'lead.qa@example.com');

  const postTaskStoriesResponse = await fetch(`${baseUrl}/api/stories`);
  assert.equal(postTaskStoriesResponse.status, 200);
  const postTaskStories = await postTaskStoriesResponse.json();
  const refreshedStory = postTaskStories.find((item) => item.id === story.id);
  assert.ok(refreshedStory);
  assert.ok(Array.isArray(refreshedStory.tasks));
  assert.ok(refreshedStory.tasks.some((task) => task.id === createdTask.id && task.status === 'Done'));
  const postTaskCount = refreshedStory.tasks.length;

  const deleteTaskResponse = await fetch(`${baseUrl}/api/tasks/${createdTask.id}`, {
    method: 'DELETE',
  });
  assert.equal(deleteTaskResponse.status, 204);
  await deleteTaskResponse.text();

  const postDeleteStoriesResponse = await fetch(`${baseUrl}/api/stories`);
  assert.equal(postDeleteStoriesResponse.status, 200);
  const postDeleteStories = await postDeleteStoriesResponse.json();
  const afterDeleteStory = postDeleteStories.find((item) => item.id === story.id);
  assert.ok(afterDeleteStory);
  assert.ok(Array.isArray(afterDeleteStory.tasks));
  assert.equal(afterDeleteStory.tasks.length, postTaskCount - 1);
  assert.ok(afterDeleteStory.tasks.every((task) => task.id !== createdTask.id));
  assert.ok(afterDeleteStory.tasks.length >= originalTaskCount);

  const fallbackComponent = primaryComponents[0] || COMPONENT_CATALOG[0] || 'WorkModel';
  const invalidStoryPoint = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Bad estimation',
      storyPoint: -2,
      asA: 'User',
      iWant: 'do something',
      soThat: 'it works',
      components: [fallbackComponent],
    }),
  });
  assert.equal(invalidStoryPoint.status, 400);
  const invalidBody = await invalidStoryPoint.json();
  assert.match(invalidBody.message, /Story point/i);

  const invalidComponents = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Bad components',
      asA: 'User',
      iWant: 'use unknown scope',
      soThat: 'tests coverage exists',
      components: ['Unknown scope'],
    }),
  });
  assert.equal(invalidComponents.status, 400);
  const invalidComponentsBody = await invalidComponents.json();
  assert.equal(invalidComponentsBody.code, 'INVALID_COMPONENTS');
  assert.ok(invalidComponentsBody.details);

  const docResponse = await fetch(`${baseUrl}/api/stories/${story.id}/reference-documents`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'API Spec', url: 'https://example.com/api' }),
  });
  assert.equal(docResponse.status, 201);
  const doc = await docResponse.json();
  assert.equal(doc.name, 'API Spec');

  const uploadResponse = await fetch(`${baseUrl}/api/uploads?filename=checklist.txt`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: Buffer.from('Security review must cover 5 controls'),
  });
  assert.equal(uploadResponse.status, 201);
  const uploadInfo = await uploadResponse.json();
  assert.ok(uploadInfo.url.startsWith('/uploads/'));
  const uploadsDir = path.join(path.dirname(DATABASE_PATH), '..', 'uploads');
  const uploadPath = path.join(uploadsDir, path.basename(uploadInfo.url));
  await fs.access(uploadPath);

  const localDocResponse = await fetch(`${baseUrl}/api/stories/${story.id}/reference-documents`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Uploaded Checklist', url: uploadInfo.url }),
  });
  assert.equal(localDocResponse.status, 201);
  const localDoc = await localDocResponse.json();
  assert.equal(localDoc.name, 'Uploaded Checklist');

  const fileFetch = await fetch(`${baseUrl}${uploadInfo.url}`);
  assert.equal(fileFetch.status, 200);
  const fileText = await fileFetch.text();
  assert.match(fileText, /Security review/);

  const deleteLocal = await fetch(`${baseUrl}/api/reference-documents/${localDoc.id}`, {
    method: 'DELETE',
  });
  assert.equal(deleteLocal.status, 204);
  await assert.rejects(fs.stat(uploadPath));

  const finalStories = await fetch(`${baseUrl}/api/stories`);
  const finalData = await finalStories.json();
  assert.equal(finalData[0].referenceDocuments.length, 1);
  if (finalData[0].acceptanceTests.length) {
    assert.ok(finalData[0].acceptanceTests[0].gwtHealth);
  }

  const runtimeResponse = await fetch(`${baseUrl}/api/runtime-data`);
  assert.equal(runtimeResponse.status, 200);
  const disposition = runtimeResponse.headers.get('content-disposition') ?? '';
  assert.match(disposition, /app\.sqlite/);
  const runtimeBuffer = Buffer.from(await runtimeResponse.arrayBuffer());
  assert.ok(runtimeBuffer.length > 0, 'Runtime data download should return file contents');
  const header = Buffer.from('SQLite format 3\0');
  assert.deepEqual(
    runtimeBuffer.subarray(0, header.length),
    header,
    'Runtime data should be a valid SQLite database file'
  );
  await fs.access(DATABASE_PATH);
});

test('acceptance tests allow observable outcomes without numeric metrics', async (t) => {
  await resetDatabaseFiles();
  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const storiesResponse = await fetch(`${baseUrl}/api/stories`);
  assert.equal(storiesResponse.status, 200);
  const stories = await storiesResponse.json();
  assert.ok(Array.isArray(stories));
  assert.ok(stories.length > 0);
  const story = stories[0];

  const payload = {
    given: ['Given an auditor is on the approvals page'],
    when: ['When they approve a pending request'],
    then: ['Then a confirmation banner is displayed and the request status updates to Approved'],
    status: 'Draft',
  };

  const createResponse = await fetch(`${baseUrl}/api/stories/${story.id}/tests`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  assert.equal(createResponse.status, 201);
  const created = await createResponse.json();
  assert.ok(created);
  assert.equal(created.status, 'Draft');
  assert.ok(Array.isArray(created.then));
  assert.ok(
    created.then[0].toLowerCase().includes('confirmation banner'),
    'Then step should reflect the observable outcome'
  );
  assert.ok(created.gwtHealth);
  assert.equal(
    created.gwtHealth.satisfied,
    true,
    'Observable outcomes should satisfy GWT health checks'
  );
  assert.ok(Array.isArray(created.gwtHealth.issues));
  assert.equal(created.gwtHealth.issues.length, 0);
  assert.ok(Array.isArray(created.measurabilityWarnings));
  assert.equal(created.measurabilityWarnings.length, 0);
});

test('acceptance tests treat DoD and blocker statements as observable outcomes', async (t) => {
  await resetDatabaseFiles();
  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const storiesResponse = await fetch(`${baseUrl}/api/stories`);
  assert.equal(storiesResponse.status, 200);
  const stories = await storiesResponse.json();
  assert.ok(Array.isArray(stories));
  assert.ok(stories.length > 0);
  const story = stories[0];

  const payload = {
    given: ['Given the story acceptance criteria are defined'],
    when: ['When the delivery team reviews the Definition of Done checklist'],
    then: ['Then outputs for the story meet DoD standards', 'And no open blockers remain for the release'],
    status: 'Draft',
  };

  const response = await fetch(`${baseUrl}/api/stories/${story.id}/tests`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  assert.equal(response.status, 201);
  const created = await response.json();
  assert.ok(created);
  assert.ok(created.gwtHealth);
  assert.equal(created.gwtHealth.satisfied, true);
  assert.ok(Array.isArray(created.gwtHealth.issues));
  assert.equal(created.gwtHealth.issues.length, 0);
  assert.ok(Array.isArray(created.measurabilityWarnings));
  assert.equal(created.measurabilityWarnings.length, 0);
});

test('story dependencies can be added and removed through the API', async (t) => {
  await resetDatabaseFiles();
  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const primaryPayload = {
    title: 'Mindmap dependency manager',
    description: 'Allow PMs to manage story links from the details panel.',
    asA: 'As a portfolio manager',
    iWant: 'I want to connect related work items',
    soThat: 'So that delivery blockers are visible early',
    components: COMPONENT_CATALOG.length ? [COMPONENT_CATALOG[0]] : ['WorkModel'],
    storyPoint: 3,
    assigneeEmail: 'pm@example.com',
  };

  const createPrimary = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(primaryPayload),
  });
  assert.equal(createPrimary.status, 201);
  const primaryStory = await createPrimary.json();
  assert.ok(primaryStory);

  const dependencyPayload = {
    ...primaryPayload,
    title: 'Audit downstream integrations',
    assigneeEmail: 'integration@example.com',
  };
  const createDependency = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dependencyPayload),
  });
  assert.equal(createDependency.status, 201);
  const dependencyStory = await createDependency.json();
  assert.ok(dependencyStory);

  const blockerPayload = {
    ...primaryPayload,
    title: 'Resolve authentication blockers',
    assigneeEmail: 'security@example.com',
  };
  const createBlocker = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(blockerPayload),
  });
  assert.equal(createBlocker.status, 201);
  const blockerStory = await createBlocker.json();
  assert.ok(blockerStory);

  const linkResponse = await fetch(`${baseUrl}/api/stories/${primaryStory.id}/dependencies`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ dependsOnStoryId: dependencyStory.id, relationship: 'depends' }),
  });
  assert.equal(linkResponse.status, 201);
  const linked = await linkResponse.json();
  assert.ok(linked);
  assert.ok(Array.isArray(linked.dependencies));
  assert.ok(linked.dependencies.some((entry) => entry.storyId === dependencyStory.id));

  const blockResponse = await fetch(`${baseUrl}/api/stories/${primaryStory.id}/dependencies`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ dependsOnStoryId: blockerStory.id, relationship: 'blocks' }),
  });
  assert.equal(blockResponse.status, 201);
  const blocked = await blockResponse.json();
  assert.ok(blocked);
  assert.ok(Array.isArray(blocked.blockedBy));
  assert.ok(blocked.blockedBy.some((entry) => entry.storyId === blockerStory.id));

  const deleteResponse = await fetch(
    `${baseUrl}/api/stories/${primaryStory.id}/dependencies/${dependencyStory.id}`,
    {
      method: 'DELETE',
    }
  );
  assert.equal(deleteResponse.status, 200);
  const afterDelete = await deleteResponse.json();
  assert.ok(Array.isArray(afterDelete.dependencies));
  assert.ok(afterDelete.dependencies.every((entry) => entry.storyId !== dependencyStory.id));
});

test('story Done status requires completed children and passing tests', async (t) => {
  await resetDatabaseFiles();
  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const parentPayload = {
    title: 'Portfolio alignment dashboard',
    description: 'Provide a dashboard for PMO leadership.',
    asA: 'As a portfolio manager',
    iWant: 'I want to review initiative health across components',
    soThat: 'So that I can proactively balance workload and risks',
    components: COMPONENT_CATALOG.length ? [COMPONENT_CATALOG[0]] : ['WorkModel'],
    storyPoint: 5,
    assigneeEmail: 'pmo@example.com',
  };

  const createParentResponse = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(parentPayload),
  });
  assert.equal(createParentResponse.status, 201);
  const parentStory = await createParentResponse.json();
  assert.ok(parentStory);

  const blockedResponse = await fetch(`${baseUrl}/api/stories/${parentStory.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...parentPayload,
      status: 'Done',
      acceptWarnings: true,
    }),
  });
  assert.equal(blockedResponse.status, 409);
  const blocked = await blockedResponse.json();
  assert.equal(blocked.code, 'STORY_STATUS_BLOCKED');
  assert.ok(blocked.details);
  assert.equal(typeof blocked.details.missingTests, 'boolean');

  const childPayload = {
    title: 'Audit-ready scorecards',
    description: 'Generate compliance scorecards for each component.',
    asA: 'As an auditor',
    iWant: 'I want to download portfolio scorecards',
    soThat: 'So that regulatory reviews start with trusted baselines',
    components:
      COMPONENT_CATALOG.length > 1 ? [COMPONENT_CATALOG[1]] : [COMPONENT_CATALOG[0]],
    storyPoint: 3,
    assigneeEmail: 'auditor@example.com',
    parentId: parentStory.id,
  };

  const createChildResponse = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(childPayload),
  });
  assert.equal(createChildResponse.status, 201);
  const childStory = await createChildResponse.json();
  assert.ok(childStory);
  assert.ok(Array.isArray(childStory.acceptanceTests));
  assert.ok(childStory.acceptanceTests.length > 0);

  const childTest = childStory.acceptanceTests[0];
  const updateChildTestResponse = await fetch(`${baseUrl}/api/tests/${childTest.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      given: childTest.given,
      when: childTest.when,
      then: childTest.then,
      status: 'Pass',
    }),
  });
  assert.equal(updateChildTestResponse.status, 200);

  const updateChildStoryResponse = await fetch(`${baseUrl}/api/stories/${childStory.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...childPayload,
      status: 'Done',
      acceptWarnings: true,
    }),
  });
  assert.equal(updateChildStoryResponse.status, 200);

  const refreshResponse = await fetch(`${baseUrl}/api/stories`);
  assert.equal(refreshResponse.status, 200);
  const tree = await refreshResponse.json();
  const flattened = [];
  (function walk(nodes) {
    nodes.forEach((node) => {
      flattened.push(node);
      if (Array.isArray(node.children) && node.children.length) {
        walk(node.children);
      }
    });
  })(tree);

  const refreshedParent = flattened.find((node) => node.id === parentStory.id);
  assert.ok(refreshedParent);
  assert.ok(Array.isArray(refreshedParent.acceptanceTests));
  assert.ok(refreshedParent.acceptanceTests.length > 0);

  const parentTest = refreshedParent.acceptanceTests[0];
  const updateParentTestResponse = await fetch(`${baseUrl}/api/tests/${parentTest.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      given: parentTest.given,
      when: parentTest.when,
      then: parentTest.then,
      status: 'Pass',
    }),
  });
  assert.equal(updateParentTestResponse.status, 200);

  const completeResponse = await fetch(`${baseUrl}/api/stories/${parentStory.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...parentPayload,
      status: 'Done',
      acceptWarnings: true,
    }),
  });
  assert.equal(completeResponse.status, 200);
  const completed = await completeResponse.json();
  assert.equal(completed.status, 'Done');
  assert.ok(completed.acceptanceTests.every((test) => test.status === 'Pass'));
});

test('story health recheck endpoint recalculates INVEST warnings', async (t) => {
  await resetDatabaseFiles();
  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const storiesResponse = await fetch(`${baseUrl}/api/stories`);
  const stories = await storiesResponse.json();
  const story = stories[0];

  const patchResponse = await fetch(`${baseUrl}/api/stories/${story.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: story.title,
      description: story.description,
      asA: '',
      iWant: story.iWant,
      soThat: '',
      acceptWarnings: true,
    }),
  });
  assert.equal(patchResponse.status, 200);

  const recheckResponse = await fetch(`${baseUrl}/api/stories/${story.id}/health-check`, {
    method: 'POST',
  });
  assert.equal(recheckResponse.status, 200);
  const refreshed = await recheckResponse.json();
  assert.equal(refreshed.id, story.id);
  assert.ok(refreshed.investHealth);
  assert.equal(refreshed.investHealth.satisfied, false);
  assert.ok(Array.isArray(refreshed.investWarnings));
  assert.ok(
    refreshed.investWarnings.some(
      (warning) => /persona/i.test(warning.message) || /So that/i.test(warning.message)
    )
  );
  assert.ok(refreshed.investAnalysis);
  assert.ok(['heuristic', 'fallback', 'openai'].includes(refreshed.investAnalysis.source));
});

test('ChatGPT analysis drives INVEST outcome when available', async (t) => {
  await resetDatabaseFiles();
  const previousDisable = process.env.AI_PM_DISABLE_OPENAI;
  const previousKey = process.env.AI_PM_OPENAI_API_KEY;
  process.env.AI_PM_DISABLE_OPENAI = '0';
  process.env.AI_PM_OPENAI_API_KEY = 'test-key';

  const originalFetch = global.fetch;
  const { Response } = globalThis;
  const aiPayload = {
    choices: [
      {
        message: {
          content: JSON.stringify({ summary: 'Story looks ready for delivery.', warnings: [] }),
        },
      },
    ],
  };

  global.fetch = async (input, init) => {
    const url = typeof input === 'string' ? input : input?.url || input?.href;
    if (url && /chat\/completions/.test(url)) {
      try {
        const body = init?.body ? JSON.parse(init.body) : null;
        const systemContent = body?.messages?.[0]?.content || '';
        if (typeof systemContent === 'string' && systemContent.includes('Given/When/Then acceptance tests')) {
          const acceptancePayload = {
            choices: [
              {
                message: {
                  content: JSON.stringify({
                    summary: 'Scenario covers login success path.',
                    titleSuffix: 'AI verification',
                    given: ['Given an admin is signed in'],
                    when: ['When they schedule a deployment window'],
                    then: ['Then the schedule is saved within 1 minute and appears on the rollout calendar'],
                  }),
                },
              },
            ],
          };
          return new Response(JSON.stringify(acceptancePayload), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
          });
        }
      } catch {
        // fall through to default payload
      }
      return new Response(JSON.stringify(aiPayload), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    }
    return originalFetch(input, init);
  };

  const { server, port } = await startServer();

  t.after(async () => {
    if (previousDisable === undefined) {
      delete process.env.AI_PM_DISABLE_OPENAI;
    } else {
      process.env.AI_PM_DISABLE_OPENAI = previousDisable;
    }
    if (previousKey) {
      process.env.AI_PM_OPENAI_API_KEY = previousKey;
    } else {
      delete process.env.AI_PM_OPENAI_API_KEY;
    }
    global.fetch = originalFetch;
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const aiComponents = COMPONENT_CATALOG.slice(1, 3).length
    ? COMPONENT_CATALOG.slice(1, 3)
    : COMPONENT_CATALOG.slice(0, Math.min(2, COMPONENT_CATALOG.length));
  const createResponse = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'AI validated story',
      asA: 'Platform admin',
      iWant: 'configure rollout windows',
      soThat: 'deployments avoid peak hours',
      description: 'Story without acceptance tests to trigger heuristic guidance',
      components: aiComponents,
    }),
  });

  assert.equal(createResponse.status, 201);
  const created = await createResponse.json();
  assert.equal(created.investAnalysis.source, 'openai');
  assert.equal(created.investHealth.satisfied, true);
  assert.ok(Array.isArray(created.investAnalysis.fallbackWarnings));
  assert.ok(Array.isArray(created.acceptanceTests));
  assert.ok(created.acceptanceTests.length >= 1);
  assert.deepEqual(created.components, aiComponents);
  assert.ok(
    created.acceptanceTests.every((test) => test.status === 'Draft'),
    'AI reviewed story should still gain a draft acceptance test for verification'
  );
  assert.equal(created.investHealth.issues.length, 0);
});

test('baseline INVEST heuristics flag dependency, negotiable, estimable, and sizing issues', async (t) => {
  await resetDatabaseFiles();
  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const warningComponents = COMPONENT_CATALOG.slice(3, 5).length
    ? COMPONENT_CATALOG.slice(3, 5)
    : COMPONENT_CATALOG.slice(0, Math.min(2, COMPONENT_CATALOG.length));
  const warningPayload = {
    title: 'Blocked by analytics overhaul',
    asA: 'Platform PM',
    iWant:
      'deliver a pixel-perfect analytics dashboard that must use Library Y and depends on Story XYZ',
    soThat: 'leadership can review metrics quickly',
    description:
      'Blocked by story 123 and requires story ABC to complete. UI must use library Y with exact 24px spacing; scope spans multiple teams and needs discovery for an unknown API.',
    storyPoint: 13,
    components: warningComponents,
  };

  const warningResponse = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(warningPayload),
  });

  assert.equal(warningResponse.status, 409);
  const warningBody = await warningResponse.json();
  assert.equal(warningBody.code, 'INVEST_WARNINGS');
  assert.ok(Array.isArray(warningBody.warnings));

  const independentIssue = warningBody.warnings.find((issue) => issue.criterion === 'independent');
  assert.ok(independentIssue, 'independent warning expected');
  assert.match(independentIssue.details, /Independent/);

  const negotiableIssue = warningBody.warnings.find((issue) => issue.criterion === 'negotiable');
  assert.ok(negotiableIssue, 'negotiable warning expected');
  assert.match(negotiableIssue.details, /Negotiable/);

  const estimableIssue = warningBody.warnings.find((issue) => issue.criterion === 'estimable');
  assert.ok(estimableIssue, 'estimable warning expected');
  assert.match(estimableIssue.details, /Estimable/);

  const smallIssue = warningBody.warnings.find((issue) => issue.criterion === 'small');
  assert.ok(smallIssue, 'small warning expected');
  assert.match(smallIssue.details, /Small/);

  const testableIssue = warningBody.warnings.find((issue) => issue.criterion === 'testable');
  assert.ok(testableIssue, 'testable warning expected');
  assert.match(testableIssue.details, /Testable/);

  const okResponse = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...warningPayload, acceptWarnings: true }),
  });

  assert.equal(okResponse.status, 201);
  const created = await okResponse.json();
  assert.ok(Array.isArray(created.investHealth.issues));
  assert.ok(created.investHealth.issues.some((issue) => issue.criterion === 'independent'));
});

test('document generation endpoints produce tailored content', async (t) => {
  await resetDatabaseFiles();
  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const testDocResponse = await fetch(`${baseUrl}/api/documents/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'common-test-document' }),
  });
  assert.equal(testDocResponse.status, 200);
  const testDocContent = await testDocResponse.text();
  assert.match(testDocResponse.headers.get('content-type') || '', /text\/markdown/i);
  assert.ok(/#\s+Common Test Document/i.test(testDocContent));
  assert.ok(/Requirement Traceability Matrix/i.test(testDocContent));
  assert.ok(/Detailed Test Procedures/i.test(testDocContent));
  const testDocSource = testDocResponse.headers.get('x-document-source');
  assert.ok(['fallback', 'baseline', 'openai'].includes(testDocSource));
  const testDisposition = testDocResponse.headers.get('content-disposition') || '';
  assert.ok(/\.md/i.test(testDisposition));

  const systemDocResponse = await fetch(`${baseUrl}/api/documents/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'common-requirement-specification' }),
  });
  assert.equal(systemDocResponse.status, 200);
  const systemDocContent = await systemDocResponse.text();
  assert.match(systemDocResponse.headers.get('content-type') || '', /text\/markdown/i);
  assert.ok(/#\s+Common Requirement Specification/i.test(systemDocContent));
  assert.ok(/Requirements Catalogue/i.test(systemDocContent));
  assert.ok(/Requirement Statement/i.test(systemDocContent));
  const systemDocSource = systemDocResponse.headers.get('x-document-source');
  assert.ok(['fallback', 'baseline', 'openai'].includes(systemDocSource));
  const systemDisposition = systemDocResponse.headers.get('content-disposition') || '';
  assert.ok(/\.md/i.test(systemDisposition));

  const badTypeResponse = await fetch(`${baseUrl}/api/documents/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'unknown' }),
  });
  assert.equal(badTypeResponse.status, 400);
});

test('acceptance tests can be created when legacy title column exists', async (t) => {
  await resetDatabaseFiles();
  await fs.mkdir(path.dirname(DATABASE_PATH), { recursive: true });
  const db = await openDatabase(DATABASE_PATH);
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE user_stories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      mr_id INTEGER DEFAULT 1,
      parent_id INTEGER,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      as_a TEXT DEFAULT '',
      i_want TEXT DEFAULT '',
      so_that TEXT DEFAULT '',
      story_point INTEGER,
      assignee_email TEXT DEFAULT '',
      status TEXT DEFAULT 'Draft',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE acceptance_tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      story_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      given TEXT NOT NULL,
      when_step TEXT NOT NULL,
      then_step TEXT NOT NULL,
      status TEXT DEFAULT 'Draft',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE reference_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      story_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      url TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);
  db.close();

  const { server, port } = await startServer();

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const storiesResponse = await fetch(`${baseUrl}/api/stories`);
  assert.equal(storiesResponse.status, 200);
  const stories = await storiesResponse.json();
  assert.ok(stories.length > 0);
  const story = stories[0];

  const createResponse = await fetch(`${baseUrl}/api/stories/${story.id}/tests`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      given: ['a signed-in customer'],
      when: ['they reset their MFA device'],
      then: ['recovery completes within 30 seconds'],
    }),
  });
  assert.equal(createResponse.status, 201);
  const created = await createResponse.json();
  assert.deepEqual(created.given, ['a signed-in customer']);
  assert.ok(Object.prototype.hasOwnProperty.call(created, 'title'));
  assert.ok(String(created.title || '').length > 0);
});

test('JSON fallback driver seeds and serves data when forced', async (t) => {
  await resetDatabaseFiles();
  resetDatabaseFactory();
  process.env.AI_PM_FORCE_JSON_DB = '1';

  const { server, port } = await startServer();

  t.after(async () => {
    delete process.env.AI_PM_FORCE_JSON_DB;
    resetDatabaseFactory();
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const storiesResponse = await fetch(`${baseUrl}/api/stories`);
  assert.equal(storiesResponse.status, 200);
  const stories = await storiesResponse.json();
  assert.ok(Array.isArray(stories));
  assert.ok(stories.length > 0);
  const fileInfo = await fs.readFile(`${DATABASE_PATH}.json`, 'utf8');
  const parsed = JSON.parse(fileInfo);
  assert.equal(parsed.driver, 'json-fallback');
});

test('JSON fallback DELETE statements clear tables when executed via exec', async () => {
  await resetDatabaseFiles();
  resetDatabaseFactory();
  process.env.AI_PM_FORCE_JSON_DB = '1';

  const db = await openDatabase(DATABASE_PATH);
  const now = new Date().toISOString();
  db.prepare(
    'INSERT INTO user_stories (title, description, as_a, i_want, so_that, components, story_point, assignee_email, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)' // prettier-ignore
  ).run(
    'Fallback delete smoke',
    'Ensures exec DELETE behaves like SQLite',
    'QA lead',
    'verify JSON truncation',
    'we trust mirrored storage',
    JSON.stringify(['WorkModel']),
    2,
    'qa@example.com',
    'Draft',
    now,
    now
  );

  const before = db.prepare('SELECT COUNT(*) as count FROM user_stories').get();
  assert.equal(Number(before.count), 1);

  db.exec(`
    DELETE FROM acceptance_tests;
    DELETE FROM reference_documents;
    DELETE FROM tasks;
    DELETE FROM story_dependencies;
    DELETE FROM user_stories;
  `);

  const after = db.prepare('SELECT COUNT(*) as count FROM user_stories').get();
  assert.equal(Number(after.count), 0);

  db.close?.();
  resetDatabaseFactory();
  delete process.env.AI_PM_FORCE_JSON_DB;

  const snapshot = JSON.parse(await fs.readFile(`${DATABASE_PATH}.json`, 'utf8'));
  assert.equal(snapshot.tables.user_stories.length, 0);
  assert.equal(snapshot.sequences.user_stories, 0);
});

test('story dependency APIs work with JSON fallback database', async (t) => {
  await resetDatabaseFiles();
  resetDatabaseFactory();
  process.env.AI_PM_FORCE_JSON_DB = '1';

  const { server, port } = await startServer();

  t.after(async () => {
    delete process.env.AI_PM_FORCE_JSON_DB;
    resetDatabaseFactory();
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const primaryPayload = {
    title: 'JSON fallback dependency source',
    description: 'Seed story for JSON driver dependency checks.',
    asA: 'As a test harness',
    iWant: 'I want to add dependencies',
    soThat: 'So that fallback storage remains feature complete',
    components: COMPONENT_CATALOG.length ? [COMPONENT_CATALOG[0]] : ['WorkModel'],
    storyPoint: 2,
    assigneeEmail: 'json@example.com',
  };

  const createPrimary = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(primaryPayload),
  });
  assert.equal(createPrimary.status, 201);
  const primaryStory = await createPrimary.json();
  assert.ok(primaryStory);

  const dependencyPayload = { ...primaryPayload, title: 'Fallback dependency target' };
  const createDependency = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dependencyPayload),
  });
  assert.equal(createDependency.status, 201);
  const dependencyStory = await createDependency.json();
  assert.ok(dependencyStory);

  const linkResponse = await fetch(`${baseUrl}/api/stories/${primaryStory.id}/dependencies`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ dependsOnStoryId: dependencyStory.id, relationship: 'depends' }),
  });
  assert.equal(linkResponse.status, 201);
  const linked = await linkResponse.json();
  assert.ok(Array.isArray(linked.dependencies));
  assert.ok(linked.dependencies.some((entry) => entry.storyId === dependencyStory.id));

  const deleteResponse = await fetch(
    `${baseUrl}/api/stories/${primaryStory.id}/dependencies/${dependencyStory.id}`,
    { method: 'DELETE' }
  );
  assert.equal(deleteResponse.status, 200);
  const afterDelete = await deleteResponse.json();
  assert.ok(Array.isArray(afterDelete.dependencies));
  assert.ok(afterDelete.dependencies.every((entry) => entry.storyId !== dependencyStory.id));
});

test('story Done status honors acceptance tests with JSON fallback database', async (t) => {
  await resetDatabaseFiles();
  resetDatabaseFactory();
  process.env.AI_PM_FORCE_JSON_DB = '1';

  const { server, port } = await startServer();

  t.after(async () => {
    delete process.env.AI_PM_FORCE_JSON_DB;
    resetDatabaseFactory();
    await new Promise((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
  });

  const baseUrl = `http://127.0.0.1:${port}`;
  const storyPayload = {
    title: 'JSON fallback done gating',
    description: 'Ensure Done validation inspects acceptance tests in fallback mode.',
    asA: 'As a quality lead',
    iWant: 'I want to verify acceptance coverage enforcement',
    soThat: 'So that done stories always include passing tests',
    components: COMPONENT_CATALOG.length ? [COMPONENT_CATALOG[0]] : ['WorkModel'],
    storyPoint: 3,
    assigneeEmail: 'fallback@example.com',
  };

  const createStoryResponse = await fetch(`${baseUrl}/api/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(storyPayload),
  });
  assert.equal(createStoryResponse.status, 201);
  const story = await createStoryResponse.json();
  assert.ok(Array.isArray(story.acceptanceTests));
  assert.ok(story.acceptanceTests.length > 0);

  const acceptanceTest = story.acceptanceTests[0];
  const updateTestResponse = await fetch(`${baseUrl}/api/tests/${acceptanceTest.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      given: acceptanceTest.given,
      when: acceptanceTest.when,
      then: acceptanceTest.then,
      status: 'Pass',
    }),
  });
  assert.equal(updateTestResponse.status, 200);

  const updatePayload = {
    title: story.title,
    description: story.description,
    asA: story.asA,
    iWant: story.iWant,
    soThat: story.soThat,
    storyPoint: story.storyPoint,
    assigneeEmail: story.assigneeEmail,
    components: Array.isArray(story.components) ? story.components : storyPayload.components,
    status: 'Done',
    acceptWarnings: true,
  };

  const markDoneResponse = await fetch(`${baseUrl}/api/stories/${story.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updatePayload),
  });
  assert.equal(markDoneResponse.status, 200);
  const completed = await markDoneResponse.json();
  assert.equal(completed.status, 'Done');
  assert.ok(
    Array.isArray(completed.acceptanceTests) &&
      completed.acceptanceTests.every((test) => test.status === 'Pass')
  );
});

test('sample dataset generator produces 50 stories and mirrored acceptance tests', async () => {
  const outputPath = path.join(process.cwd(), 'docs', 'examples', 'generated-sample.sqlite');
  await fs.rm(outputPath, { force: true });
  await fs.rm(`${outputPath}.json`, { force: true });

  const summary = await generateSampleDataset(outputPath);
  assert.equal(summary.storyCount, 50);
  assert.ok(
    summary.acceptanceTestCount >= 50,
    'Sample dataset should include at least one acceptance test per story'
  );

  const db = await openDatabase(outputPath);
  const storyCountRow = db.prepare('SELECT COUNT(*) AS count FROM user_stories').get();
  const testCountRow = db.prepare('SELECT COUNT(*) AS count FROM acceptance_tests').get();
  db.close?.();
  resetDatabaseFactory();

  assert.equal(Number(storyCountRow.count), 50);
  assert.equal(Number(testCountRow.count), summary.acceptanceTestCount);

  await fs.rm(outputPath, { force: true });
  await fs.rm(`${outputPath}.json`, { force: true });
});
