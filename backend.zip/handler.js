const { createApp } = require('./apps/backend/app.js');

let app;

exports.handler = async (event, context) => {
  if (!app) {
    app = await createApp();
  }
  
  const { method, path, headers, body } = event;
  
  return new Promise((resolve) => {
    const req = {
      method,
      url: path,
      headers,
      body: body ? Buffer.from(body, 'base64') : undefined
    };
    
    const res = {
      statusCode: 200,
      headers: {},
      body: '',
      setHeader: function(name, value) { this.headers[name] = value; },
      writeHead: function(code, headers) { 
        this.statusCode = code; 
        if (headers) Object.assign(this.headers, headers);
      },
      end: function(data) {
        this.body = data || '';
        resolve({
          statusCode: this.statusCode,
          headers: { ...this.headers, 'Access-Control-Allow-Origin': '*' },
          body: this.body
        });
      }
    };
    
    app(req, res);
  });
};
