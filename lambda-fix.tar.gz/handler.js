const { createApp } = require('./apps/backend/app.js');

let app;

exports.handler = async (event, context) => {
  if (!app) {
    app = await createApp();
  }
  
  // Add CORS headers to all responses
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Amz-User-Agent',
    'Access-Control-Allow-Methods': 'OPTIONS,DELETE,GET,HEAD,PATCH,POST,PUT'
  };
  
  // Handle preflight OPTIONS requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }
  
  return new Promise((resolve, reject) => {
    const req = {
      method: event.httpMethod,
      url: event.path + (event.queryStringParameters ? '?' + new URLSearchParams(event.queryStringParameters).toString() : ''),
      headers: event.headers || {},
      body: event.body
    };
    
    const res = {
      statusCode: 200,
      headers: { ...corsHeaders },
      body: '',
      writeHead: function(code, headers) {
        this.statusCode = code;
        if (headers) Object.assign(this.headers, headers);
      },
      write: function(data) {
        this.body += data;
      },
      end: function(data) {
        if (data) this.body += data;
        resolve({
          statusCode: this.statusCode,
          headers: this.headers,
          body: this.body
        });
      }
    };
    
    // Simulate Express request/response
    app.listeners('request')[0](req, res);
  });
};
