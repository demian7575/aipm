const serverlessExpress = require('@vendia/serverless-express');

let serverlessExpressInstance;

async function setup(event, context) {
  const { createApp } = require('./apps/backend/app.js');
  const app = await createApp();
  serverlessExpressInstance = serverlessExpress({ app });
  return serverlessExpressInstance(event, context);
}

exports.handler = (event, context) => {
  if (serverlessExpressInstance) return serverlessExpressInstance(event, context);
  return setup(event, context);
};
